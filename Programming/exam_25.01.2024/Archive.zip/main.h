#ifndef EXAM_25_01_2024_MAIN_H
#define EXAM_25_01_2024_MAIN_H

namespace commands {
    extern char story[];
    extern char task[];
    extern char exam[];
    //Taylor swift
    extern char TS[];
    //Cancer culture
    extern char CCT[];
    //Random stuff
    extern char RS[];
}

#endif //EXAM_25_01_2024_MAIN_H
